<?php 

//add_action('wp_ajax_my_actionk', 'my_actionk');
//add_action('wp_ajax_nopriv_my_actionk', 'my_actionk');
function my_actionk($email)
 {
	$sign_email = $email;
   $email =  $email;
   require_once 'mailchimp/MAPI.class.php'; 
   require_once 'mailchimp/mailchimp.php';  
  
}