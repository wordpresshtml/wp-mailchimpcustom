<?php
/**
This Example shows how to Subscribe a New Member to a List using the MCAPI.php 
class and do some basic error checking.

//http://www.wordpresshtml.com/
**/
$apikey = 'e453733753446478687vgdfghdh6469erh445342';
$api = new MCAPI($apikey);
$listId = '4645454654';
$my_email = $sign_email ;

//echo 'kkkkkkkkkk'.$formname = $_POST['formname'];
$merge_vars = array( 'EMAIL'=>$my_email );
                                 

$retval_mem = $api->listMemberInfo( $listId, array($my_email) );
//print_r($retval_mem);
$emil_sub_sucess =  $retval_mem['success'];
 if($emil_sub_sucess == 1){
   //  echo 'alredy subscribe';  
     //$alredy_subs = 0;
     $result = 0;
     
 }else{
     $retval = $api->listSubscribe( $listId, $my_email, $merge_vars );
   
     $result = 1;      
 }  
if ($api->errorCode){
	//echo "Unable to load listSubscribe()!\n";
	//echo "\tCode=".$api->errorCode."\n";
	//echo "\tMsg=".$api->errorMessage."\n";
} else {
 //  echo "Subscribed - look for the confirmation email!\n";
}  
 
echo $result;


